package com.example.demo.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Student {
	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Integer studentId;
	
	@NotEmpty(message = "Student name should not be empty")
	@Column(length=40)
	private String studentName;
	
	@NotEmpty(message = "Student mobile no should not be empty")
	@Column(length = 10,unique=true)
	private String studentMobileNo;
	
	@NotEmpty(message = "Student address should not be empty")
	private String studentAddress;
	
	@Email(message="Invalid email input")
	@Column(unique = true)
	private String studentEmail;
	
	@Min(value=18 ,message="Student age should be greater than 17")
	private int studentAge;
	
	@Min(value=1000,message = "Fees should be greater than 1000")
	private float studentFees;
	
	@JsonIgnore
	@ManyToMany(mappedBy = "student")
	private List<Subject> subject=new ArrayList<Subject>();
	
	public List<Subject> getSubject() {
		return subject;
	}
	public void setSubject(List<Subject> subject) {
		this.subject = subject;
	}
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentMobileNo() {
		return studentMobileNo;
	}
	public void setStudentMobileNo(String studentMobileNo) {
		this.studentMobileNo = studentMobileNo;
	}
	public String getStudentAddress() {
		return studentAddress;
	}
	public void setStudentAddress(String studentAddress) {
		this.studentAddress = studentAddress;
	}
	public String getStudentEmail() {
		return studentEmail;
	}
	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}
	public int getStudentAge() {
		return studentAge;
	}
	public void setStudentAge(int studentAge) {
		this.studentAge = studentAge;
	}
	public float getStudentFees() {
		return studentFees;
	}
	public void setStudentFees(float studentFees) {
		this.studentFees = studentFees;
	}
}
