package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.repository.StudentRepository;
import com.example.demo.repository.TeacherRepository;

@RestController
public class ProfitAndLossController {
	
	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private TeacherRepository teacherRepository;
	
	@GetMapping("profitOrLossOfCollege")
	public String profitAndLoss() {
		float pf=studentRepository.totalFees()-teacherRepository.totalsalary();
		if(pf>0)
		return "Profit: "+pf;
		else
			return "Loss: "+(teacherRepository.totalsalary()-studentRepository.totalFees());
	}
}
