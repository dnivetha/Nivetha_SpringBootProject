package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Teacher;
import com.example.demo.error.NotFoundException;

import com.example.demo.repository.TeacherRepository;
import com.example.demo.service.TeacherService;

@RestController
public class TeacherController {
	
	@Autowired
	private TeacherService teacherService;
	
	@Autowired
	private TeacherRepository teacherRepository;
	
	@PostMapping("/saveTeacher")
	public ResponseEntity<Teacher> addTeacher(@Valid @RequestBody Teacher teacher) {
		Teacher teacher1=teacherService.addTeacher(teacher);
		return new ResponseEntity<>(teacher1,HttpStatus.CREATED);
	}
	
	@GetMapping("/getAllTeachers") 
	public List<Teacher>getAllTeacher(){
		return teacherService.getAllTeacher();
	}
	
	@GetMapping("/getTeacherById/{tid}")
	public Teacher getTeacherById(@PathVariable("tid") Integer tid,@RequestBody Teacher teacher) throws NotFoundException {
		return teacherService.getTeacherById(tid,teacher);
	}
	
	@GetMapping("/findByTeacherName/{tname}")
	public List<Teacher> findByTeacherName(@PathVariable("tname") String teacherName) throws NotFoundException{
		return teacherService.findByTeacherName(teacherName);
	}
	
	@DeleteMapping("/deleteTeacherById/{tid}")	
	public String deleteTeacher(@PathVariable("tid") Integer tid) throws NotFoundException {
		teacherService.deleteTeacher(tid);
		return "Record is deleted";
	}
	
	@PutMapping("/updateTeacherById/{tid}")
	public Teacher updateTeacher(@PathVariable("tid") Integer tid,@RequestBody Teacher teacher) throws NotFoundException {
		return teacherService. updateTeacher(tid,teacher);
	
	}
	
	@GetMapping("/teacherTotalSalary")
	 public float teachertotalsalary() {
		 return teacherRepository.totalsalary();
	 }
}
