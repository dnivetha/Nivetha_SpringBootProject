package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Student;
import com.example.demo.error.NotFoundException;

public interface StudentService {

	Student addStudent(Student student);

	List<Student> getAllStudents();

	Student getStudentById(Integer sid) throws NotFoundException;
	
	List<Student> findByStudentName(String studentName) throws NotFoundException;
	
	void deleteStudentById(Integer sid) throws NotFoundException;

	Student updateStudent(Integer sid, Student student) throws NotFoundException;

}
