package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Student;
import com.example.demo.entity.Teacher;
import com.example.demo.error.NotFoundException;

import com.example.demo.repository.TeacherRepository;

@Service
public class TeacherServiceImpl implements TeacherService {
	
	@Autowired
	private TeacherRepository teacherRepository;

	@Override
	public Teacher addTeacher(Teacher teacher) {	
		return teacherRepository.save(teacher);
	}

	@Override
	public List<Teacher> getAllTeacher() {
		return teacherRepository.findAll();
	}

	@Override
	public Teacher getTeacherById(Integer tid, Teacher teacher) throws NotFoundException {
		Optional<Teacher>teacher1=teacherRepository.findById(tid);
		if(!teacher1.isPresent())
			throw new NotFoundException("Teacher id "+tid+" not found");
		else
			return teacherRepository.findById(tid).get();
	}
	
	@Override
	public List<Teacher> findByTeacherName(String teacherName) throws NotFoundException {
		// TODO Auto-generated method stub
		List<Teacher> student= teacherRepository.findByTeacherName(teacherName);
		if(student.isEmpty()) {
			throw new NotFoundException("Teacher name "+teacherName+" not found");
		}else
			return teacherRepository.findByTeacherName(teacherName);
	}

	@Override
	public void deleteTeacher(Integer tid) throws NotFoundException {
		Optional<Teacher> teacher1=teacherRepository.findById(tid);
		if(!teacher1.isPresent())
			throw new NotFoundException("Teacher id "+tid+" not found");
		else
			teacherRepository.deleteById(tid);
	}

	@Override
	public Teacher updateTeacher(Integer tid, Teacher teacher) throws NotFoundException {
		Optional<Teacher> teacher1=teacherRepository.findById(tid);
		if(!teacher1.isPresent())
			throw new NotFoundException("Teacher id "+tid+" not found");
		else {
			Teacher teacher2 =teacherRepository.findById(tid).get();
			
			if( teacher2.getTeacherName()!=null) 
				teacher2.setTeacherName(teacher.getTeacherName());
			
			if(teacher2.getTeacherSalary()!=0)
				teacher2.setTeacherSalary(teacher.getTeacherSalary());
			return teacherRepository.save(teacher2);
		}
	}
}
